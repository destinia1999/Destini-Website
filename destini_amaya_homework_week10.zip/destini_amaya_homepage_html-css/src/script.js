const nav = document.querySelector('.navbar a[href="#about"]');
if (navItem) {
  navItem.click();
}